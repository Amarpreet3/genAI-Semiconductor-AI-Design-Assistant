#For general python APIs

def debug_print(message, debug=False):
    if debug:
        print(f"DEBUG: {message}")