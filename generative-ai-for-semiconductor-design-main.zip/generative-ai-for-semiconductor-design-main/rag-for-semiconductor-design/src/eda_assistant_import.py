
import boto3
import sys, os
import json
import pprint
from tabulate import tabulate
from botocore.client import Config